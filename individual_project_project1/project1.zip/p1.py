# Define the main function
def main():
    # Print "Hello World" on the first line
    print("Hello World")
    
    # Prompt the user to enter their name
    your_name = input("Enter your name: ")
    
    # Greet the user using the name they entered
    print("Hello " + your_name)

# Call the main function when the script is run directly
if __name__ == "__main__":
    main()